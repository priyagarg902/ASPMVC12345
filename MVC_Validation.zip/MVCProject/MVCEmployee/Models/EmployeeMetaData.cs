﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCEmployee.Models
{
    public class EmployeeMetaData
    {
        [Required]
        public int ID { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public int Designation { get; set; }
        [Required]
        public int Department { get; set; }
    }
}