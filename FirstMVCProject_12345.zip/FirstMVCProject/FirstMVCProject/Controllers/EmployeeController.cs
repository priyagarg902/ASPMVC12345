﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FirstMVCProject.Models;using System.Data.Entity;using System.Net;using FirstMVCProject.Infrastructure;

namespace FirstMVCProject.Controllers
{
    public class EmployeeController : Controller
    {
       

        private EmployeeMgmtEntities db = new EmployeeMgmtEntities();


        // GET: /Employee/
        [ProfileAll()]
        public ActionResult Index()
        {
            var employees = db.Employee_46004314.Include(e => e.Department_46004314).Include(e =>
           e.Designation_46004314);
            return View(employees.ToList());
        }
        // GET: Employee

        // GET: /Employee/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_46004314 employee = db.Employee_46004314.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }
        // GET: /Employee/Create
        public ActionResult Create()
        {
            ViewBag.Department = new SelectList(db.Department_46004314, "ID", "Name");
            ViewBag.Designation = new SelectList(db.Designation_46004314, "ID", "Name");
            return View();
        }
        [HttpPost]
        public ActionResult Create([Bind(Include="ID,Name,Designation,Department")]
            Employee_46004314 employee)
        {
            if (ModelState.IsValid)
            {
                db.Employee_46004314.Add(employee);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Department = new SelectList(db.Department_46004314, "ID", "Name",
           employee.Department);
            ViewBag.Designation = new SelectList(db.Designation_46004314, "ID", "Name",
           employee.Designation);
            return View(employee);
        }
        // GET: /Employee/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_46004314 employee = db.Employee_46004314.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            ViewBag.Department = new SelectList(db.Department_46004314, "ID", "Name",
           employee.Department);
            ViewBag.Designation = new SelectList(db.Designation_46004314, "ID", "Name",
           employee.Designation);
            return View(employee);
        }
        // POST: /Employee/Edit/5
        [HttpPost]
        public ActionResult Edit([Bind(Include="ID,Name,Designation,Department")]
          Employee_46004314 employee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Department = new SelectList(db.Department_46004314, "ID", "Name",
             employee.Department);
            ViewBag.Designation = new SelectList(db.Designation_46004314, "ID", "Name",
           employee.Designation);
            return View(employee);
        }
        // GET: /Employee/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_46004314 employee = db.Employee_46004314.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }
        // POST: /Employee/Delete/5
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee_46004314 employee = db.Employee_46004314.Find(id);
            db.Employee_46004314.Remove(employee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }


}
