﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;

namespace FirstMVCProject.Infrastructure
{
    public class ProfileAllAttribute:FilterAttribute,IActionFilter
    {


        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
            FileStream objFS = new FileStream(@"D:\Users\ckumar28\Desktop\ASPNET MVC\Logfile\LogFile.txt", FileMode.Append, FileAccess.Write, FileShare.Read);
            StreamWriter objSW = new StreamWriter(objFS);
            objSW.WriteLine("------OnActionExcuted");
            string bname = "";
            bname = filterContext.HttpContext.Request.Browser.Browser;

            objSW.WriteLine("Browser Name is :" + bname);

            objSW.Flush();
            objSW.Close();
            objSW.Close();
        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            FileStream objFS = new FileStream(@"D:\Users\ckumar28\Desktop\ASPNET MVC\Logfile\LogFile.txt", FileMode.Append, FileAccess.Write, FileShare.Read);
            StreamWriter objSW = new StreamWriter(objFS);
            objSW.WriteLine("------OnActionExcuting------");
            objSW.WriteLine("AnonymousID:{0}, HTTPMethod: {1},"+"DateTime: {2}",filterContext.HttpContext.Request.AnonymousID,filterContext.HttpContext.Request.HttpMethod,DateTime.Now.ToLongDateString());
            objSW.WriteLine("----------------------");

            objSW.Flush();
            objSW.Close();
            objSW.Close();

        }
    }
}